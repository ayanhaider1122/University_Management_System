package com.example.universitymanagement;

import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;

@RestController
@RequestMapping("/api")
class UniversityController {
    @Autowired
    private UniversityService universityService;

    @GetMapping("/professors/{id}/courses")
    public List<Course> getCourses(@PathVariable Long id) {
        return universityService.getCoursesByProfessor(id);
    }
}
