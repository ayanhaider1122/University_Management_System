package com.example.universitymanagement;

import org.springframework.data.jpa.repository.JpaRepository;

interface ProfessorRepository extends JpaRepository<Professor, Long> {}
interface CourseRepository extends JpaRepository<Course, Long> {}
