package com.example.universitymanagement;

import javax.persistence.*;

@Entity
class Course {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;

    @ManyToOne
    @JoinColumn(name = "professor_id")
    private Professor professor;

    // Getters and Setters
}
