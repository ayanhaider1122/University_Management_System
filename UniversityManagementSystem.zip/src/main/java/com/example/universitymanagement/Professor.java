package com.example.universitymanagement;

import javax.persistence.*;
import java.util.List;

@Entity
class Professor {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;

    @OneToMany(mappedBy = "professor", cascade = CascadeType.ALL)
    private List<Course> courses;

    // Getters and Setters
}
