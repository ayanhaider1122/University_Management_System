package com.example.universitymanagement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
class UniversityService {
    @Autowired
    private ProfessorRepository professorRepository;

    @Autowired
    private CourseRepository courseRepository;

    public List<Course> getCoursesByProfessor(Long professorId) {
        return professorRepository.findById(professorId)
                .map(Professor::getCourses)
                .orElseThrow(() -> new RuntimeException("Professor not found"));
    }
}
